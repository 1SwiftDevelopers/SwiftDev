from django.apps import AppConfig


class GuestsConfig(AppConfig):
    name = 'guests'
